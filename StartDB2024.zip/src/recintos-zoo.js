class RecintosZoo {

    analisaRecintos(animal, quantidade) {
    }

}

export { RecintosZoo as RecintosZoo };
